package com.kratos.whatsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
